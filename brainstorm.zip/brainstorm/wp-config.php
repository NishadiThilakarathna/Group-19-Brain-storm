<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'brainstorm');

/** MySQL database username */
define('DB_USER', 'root');

/** MySQL database password */
define('DB_PASSWORD', '');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'Ntm63EmoB<& ^TVi$vX;oEwrW*)7fJTX9/F(^v)zKwY^6Z,leAx~_R^a?Hy:$SHu');
define('SECURE_AUTH_KEY',  'H1SiV^[sL=T#teuO:rf|o%TT@)bb%=DV}~?sv$&MclK/%2qx1yTfH]Go9kq6gFHE');
define('LOGGED_IN_KEY',    'hdcn1`sHztjfSENf Pl5MO!@)4HV<jfkN]D^u2>GeXbQ4!7OO C,!z=/Rcg#oCx%');
define('NONCE_KEY',        'MZF@;21Kzaxjoe)0Uv-jVX#m9y=e^3$~li}#0P/JwQ@0|H=#D7)/#JW~0OU4$CCd');
define('AUTH_SALT',        'u+.u ?k/*a<GG}6Dn9J8/m];H*x_nf)(*qL*;=i|l-n/RL9SH!CzF;47Gs<#K@$1');
define('SECURE_AUTH_SALT', '3;bb)]N c7xn+AQ7+o-t-`%lv-)kk3c[f(eBC=1^Gcd5BAN~<~A;>*$F& XT~/_}');
define('LOGGED_IN_SALT',   ')>pYkYppDc&wT%`x:eK~PPxGH*Yf;#T*IvTYDT4`b)lTQq!5gh@6W=bi0EKOmd$+');
define('NONCE_SALT',       'yg.dtY-b((bF#7 t4Yp4r`-eL68q34PYI%hd040Bf3,!_{L=`X 9wf.5k/aq[|c~');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
